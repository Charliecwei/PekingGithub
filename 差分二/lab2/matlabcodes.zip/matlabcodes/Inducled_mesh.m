function Inducled_mesh(I)
%% Induced the I node mesh to convex

global  node elem iner_edge   node_elem_idx;

Node_star_elem_idx = node_elem_idx{I};
Elem_star = elem(Node_star_elem_idx,:)'; 
edge_appose = sort(reshape(Elem_star(Elem_star~=I),2,[]),1)';  %% the egde as i for vecter

 Node_star_elem_idx = [];
for i = 1:size(edge_appose,1)
    Node_star_elem_idx = [ Node_star_elem_idx;EdgeElem(edge_appose(i,:))];
end

Node_star_elem_idx = unique(Node_star_elem_idx);
Elem = elem(Node_star_elem_idx,:);

[jump,Intidx,edge,~] = Jump(Elem);


[a,b] = min(jump);

showmesh(node,elem);
findnode(node);
% findelem(node,elem);

while a<0
    Edge_idx = Intidx(b);
    edge_change = sort(edge(Edge_idx,:));
    J = find((uint32(iner_edge(:,1)==edge_change(1))+uint32(iner_edge(:,2)==edge_change(2)))==2);
    Flip(J);
    
   
    Node_star_elem_idx = node_elem_idx{I};
    Elem_star = elem(Node_star_elem_idx,:)'; 
    edge_appose = sort(reshape(Elem_star(Elem_star~=I),2,[]),1)';  %% the egde as i for vecter

     Node_star_elem_idx = [];
    for i = 1:size(edge_appose,1)
        Node_star_elem_idx = [ Node_star_elem_idx;EdgeElem(edge_appose(i,:))];
    end

    Node_star_elem_idx = unique(Node_star_elem_idx);
    Elem = elem(Node_star_elem_idx,:);
    
    figure(2)
    
     showmesh(node,elem);
    findnode(node);
  %  findelem(node,elem);
    

    [jump,Intidx,edge,~] = Jump(Elem);


    [a,b] = min(jump);
end
    
    
    