function [jump,Intidx,edge,J] = Jump(elem)
%% Compute the jump
global node u0;

totalEdge = uint32([elem(:,[2,3]); elem(:,[3,1]); elem(:,[1,2])]);
totalEdges = sort(totalEdge,2);
[edge, i2, j] = unique(totalEdges,'rows','legacy');

Dphip = gradbasis(node,elem);

 Dphips(:,:,1) =  u0(elem(:,1)).*Dphip(:,:,1);
 Dphips(:,:,2) =  u0(elem(:,2)).*Dphip(:,:,2);
 Dphips(:,:,3) =  u0(elem(:,3)).*Dphip(:,:,3);
    
 Dphips = Dphips(:,:,1)+Dphips(:,:,2)+Dphips(:,:,3);
    
    
    
n_mins(:,:,1) = Dphip(:,:,1)./(sqrt(Dphip(:,1,1).^2+Dphip(:,2,1).^2)); 
n_mins(:,:,2) = Dphip(:,:,2)./(sqrt(Dphip(:,1,2).^2+Dphip(:,2,2).^2)); 
n_mins(:,:,3) = Dphip(:,:,3)./(sqrt(Dphip(:,1,3).^2+Dphip(:,2,3).^2)); 


totaldif = [dot(Dphips,n_mins(:,:,1),2);dot(Dphips,n_mins(:,:,2),2);...
                      dot(Dphips,n_mins(:,:,3),2)];


jump = accumarray(j,totaldif,size(i2));

NT = size(elem,1);
i1(j(3*NT:-1:1)) = 3*NT:-1:1; 
i1 = i1';
IntEdgeIdx = ~(i1 == i2);

jump = jump(IntEdgeIdx);
Intidx = find(IntEdgeIdx);
J = reshape(j,[],3);


