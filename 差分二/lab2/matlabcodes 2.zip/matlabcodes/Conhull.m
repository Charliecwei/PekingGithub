function s = Conhull(I)
%% Compute the Du on elem for I point and compute it's hull area
global node elem node_elem_idx u0

Elem = elem(node_elem_idx{I},:);
Dphip = gradbasis(node,Elem);

 Dphips(:,:,1) =  u0(Elem(:,1)).*Dphip(:,:,1);
 Dphips(:,:,2) =  u0(Elem(:,2)).*Dphip(:,:,2);
 Dphips(:,:,3) =  u0(Elem(:,3)).*Dphip(:,:,3);
    
 Du= Dphips(:,:,1)+Dphips(:,:,2)+Dphips(:,:,3);

 
Elem = Elem';
edge_ap = sort(reshape(Elem(Elem~=I),2,[]),1)';

ev = (node(edge_ap(:,1),:)+node(edge_ap(:,2),:))-2*node(I,:);
k = convhull(ev(:,1),ev(:,2));
 
%node_elem_idx{I} = node_elem_idx{I}(k(1:end-1));

Du = Du(k,:);


Dupv = Du(1:end-1,:);
Dupv = [-Dupv(:,2),Dupv(:,1)];

s = 0.5*sum(dot(Dupv,Du(2:end,:),2));
 
 
 
% if size(Du,1)<3
%     s = 0;
% else
%     [~,av] = convhull(Du(:,1),Du(:,2));
% end
% 
% av-s

