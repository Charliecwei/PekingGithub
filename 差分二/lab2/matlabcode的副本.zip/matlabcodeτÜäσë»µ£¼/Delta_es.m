function Delta_eu = Delta_es(u,e,h)
%%Find the Delta of u at (ih,jh) in the direction of e, and the grid size is h
global g_D;
N = 1/h;


u_l = zeros(size(u));
u_r = zeros(size(u));

rho_l = ones(size(u));
rho_r = ones(size(u));

[i,j] = GlobaltoLocalidx((1:length(u))',N);



 
%% the left 
i_l = i-rho_l*e(1);%the x value of the interpolation point on the left
j_l = j-rho_l*e(2);%the y value of the interpolation point on the left


% find the inner point
idx = and(and(1<=i_l,i_l<=N-1),and(1<=j_l,j_l<=N-1));
s = LocaltoGlobalidx(i_l(idx),j_l(idx),N);
u_l(idx) = u(s);


% find the boundary point
idx = and(i_l<1,and(1<=j_l,j_l<=N-1));
rho_l(idx) = (i(idx)-0)/(e(1));
x = (i(idx) - rho_l(idx)*e(1))*h;
y = (j(idx) - rho_l(idx)*e(2))*h;
u_l(idx) = g_D(x,y);


idx = and(i_l>N-1,and(1<=j_l,j_l<=N-1));
rho_l(idx) = (i(idx)-N)/(e(1));
x = (i(idx) - rho_l(idx)*e(1))*h;
y = (j(idx) - rho_l(idx)*e(2))*h;
u_l(idx) = g_D(x,y);


idx = and(and(1<=i_l,i_l<=N-1),j_l<1);
rho_l(idx) = (j(idx)-0)/(e(2));
x = (i(idx) - rho_l(idx)*e(1))*h;
y = (j(idx) - rho_l(idx)*e(2))*h;
u_l(idx) = g_D(x,y);


idx = and(and(1<=i_l,i_l<=N-1),j_l>N-1);
rho_l(idx) = (j(idx)-N)/(e(2));
x = (i(idx) - rho_l(idx)*e(1))*h;
y = (j(idx) - rho_l(idx)*e(2))*h;
u_l(idx) = g_D(x,y);


idx = and(i_l<1,j_l<1);
rho_l(idx) = (min([(i(idx)-0)'/(e(1));(j(idx)-0)'/e(2)]))';
x = (i(idx) - rho_l(idx)*e(1))*h;
y = (j(idx) - rho_l(idx)*e(2))*h;
u_l(idx) = g_D(x,y);



idx = and(i_l<1,j_l>N-1);
rho_l(idx) = (min([(i(idx)-0)'/(e(1));(j(idx)-N)'/e(2)]))';
x = (i(idx) - rho_l(idx)*e(1))*h;
y = (j(idx) - rho_l(idx)*e(2))*h;
u_l(idx) = g_D(x,y);


idx = and(i_l>N-1,j_l<1);
rho_l(idx) = (min([(i(idx)-N)'/(e(1));(j(idx)-0)'/e(2)]))';
x = (i(idx) - rho_l(idx)*e(1))*h;
y = (j(idx) - rho_l(idx)*e(2))*h;
u_l(idx) = g_D(x,y);


idx = and(i_l<N-1,j_l<N-1);
rho_l(idx) = (min([(i(idx)-N)'/(e(1));(j(idx)-N)'/e(2)]))';
x = (i(idx) - rho_l(idx)*e(1))*h;
y = (j(idx) - rho_l(idx)*e(2))*h;
u_l(idx) = g_D(x,y);

%%


%% the right
i_r = i+rho_r*e(1);%the x value of the interpolation point on the left
j_r = j+rho_r*e(2);%the y value of the interpolation point on the left


% find the inner point
idx = and(and(1<=i_r,i_r<=N-1),and(1<=j_r,j_r<=N-1));
s = LocaltoGlobalidx(i_r(idx),j_r(idx),N);
u_r(idx) = u(s);


% find the boundary point
idx = and(i_r<1,and(1<=j_r,j_r<=N-1));
rho_r(idx) = (0-i(idx))/(e(1));
x = (i(idx) + rho_r(idx)*e(1))*h;
y = (j(idx) + rho_r(idx)*e(2))*h;
u_r(idx) = g_D(x,y);


idx = and(i_r>N-1,and(1<=j_r,j_r<=N-1));
rho_r(idx) = (N-i(idx))/(e(1));
x = (i(idx) + rho_r(idx)*e(1))*h;
y = (j(idx) + rho_r(idx)*e(2))*h;
u_r(idx) = g_D(x,y);


idx = and(and(1<=i_r,i_r<=N-1),j_r<1);
rho_r(idx) = (0-j(idx))/(e(2));
x = (i(idx) + rho_r(idx)*e(1))*h;
y = (j(idx) + rho_r(idx)*e(2))*h;
u_r(idx) = g_D(x,y);


idx = and(and(1<=i_r,i_r<=N-1),j_r>N-1);
rho_r(idx) = (N-j(idx))/(e(2));
x = (i(idx) + rho_r(idx)*e(1))*h;
y = (j(idx) + rho_r(idx)*e(2))*h;
u_r(idx) = g_D(x,y);


idx = and(i_r<1,j_r<1);
rho_r(idx) = (min([0-(i(idx))'/(e(1));(0-j(idx))'/e(2)]))';
x = (i(idx) + rho_r(idx)*e(1))*h;
y = (j(idx) + rho_r(idx)*e(2))*h;
u_r(idx) = g_D(x,y);



idx = and(i_r<1,j_r>N-1);
rho_r(idx) = (min([(0-i(idx))'/(e(1));(N-j(idx))'/e(2)]))';
x = (i(idx) + rho_r(idx)*e(1))*h;
y = (j(idx) + rho_r(idx)*e(2))*h;
u_r(idx) = g_D(x,y);


idx = and(i_r>N-1,j_r<1);
rho_r(idx) = (min([(N-i(idx))'/(e(1));(0-j(idx))'/e(2)]))';
x = (i(idx) + rho_r(idx)*e(1))*h;
y = (j(idx) + rho_r(idx)*e(2))*h;
u_r(idx) = g_D(x,y);


idx = and(i_r<N-1,j_r<N-1);
rho_r(idx) = (min([(N-i(idx))'/(e(1));(N-j(idx))'/e(2)]))';
x = (i(idx) + rho_r(idx)*e(1))*h;
y = (j(idx) + rho_r(idx)*e(2))*h;
u_r(idx) = g_D(x,y);




Delta_eu = ((u_r-u)./rho_r-(u-u_l)./rho_l).*(2./((rho_l+rho_r).*(e(1)^2+e(2)^2).*h^2));

end






