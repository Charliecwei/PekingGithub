function Grad_Fu = Grad_MAWS_h_thetas(u,h,G,v_star_idx)
%%To calculate the Grad_u of MAWS_h_theta
Nu = length(u);
N = 1/h;
 v_star = G(v_star_idx,:);
 
 v_star_vertical = [-v_star(:,2),v_star(:,1)];
 


 ii = (1:Nu)';
 jj = ii;
 
 Delta_eu = Delta_e(u,v_star,h);
 
 Delta_eu_v = Delta_e(u,v_star_vertical,h);
 
 GraduDeltave = Grad_uOfDelta_eu(u,v_star,h);
 
 GraduDeltave_v = Grad_uOfDelta_eu(u,v_star_vertical,h);
 
 Grad_Fus =  sparse(ii,jj,Delta_eu,Nu,Nu)*GraduDeltave_v...
                    + sparse(ii,jj,Delta_eu_v,Nu,Nu)*GraduDeltave;

               
 
 

 [i,j] = GlobaltoLocalidx((1:Nu)',N);
 
[Delta_eu,Gradu_Deltaeu] = Delta_e(u,v_star,h);
 
[Delta_eu_v,Gradu_Deltaeu_v] = Delta_e(u,v_star_vertical,h);


Diag = -(Delta_eu.*sum(Gradu_Deltaeu_v,2) + Delta_eu_v.*sum( Gradu_Deltaeu,2));
%Diag = - sum( Gradu_Deltaeu,2);
 s = 1:Nu;
 Grad_Fu = sparse(s,s,Diag,Nu,Nu);

 
 %% other items for v^*
 
    i_l = i- v_star(:,1);%the x value of the interpolation point on the left
    j_l = j- v_star(:,2);%the y value of the interpolation point on the left


    i_r = i+ v_star(:,1);%the x value of the interpolation point on the left
    j_r = j+ v_star(:,2);%the y value of the interpolation point on the left
    
   
    
    
     % find the inner point for the left point
    idx = and(and(1<=i_l,i_l<=N-1),and(1<=j_l,j_l<=N-1));
    s = LocaltoGlobalidx(i_l(idx),j_l(idx),N);
    i_l_idx = find(idx);
    grad_Deltau = Gradu_Deltaeu(:,1);
    Other =  grad_Deltau(idx).*Delta_eu_v(idx);
%   Other =  grad_Deltau(idx);
    Grad_Fu = Grad_Fu + sparse(i_l_idx,s,Other,Nu,Nu);
    
    
    % find the inner point for the right point
    idx = and(and(1<=i_r,i_r<=N-1),and(1<=j_r,j_r<=N-1));
    s = LocaltoGlobalidx(i_r(idx),j_r(idx),N);
    i_r_idx = find(idx);
    grad_Deltau = Gradu_Deltaeu(:,2);
     Other =  grad_Deltau(idx).*Delta_eu_v(idx);
 %  Other = grad_Deltau(idx);
    Grad_Fu = Grad_Fu + sparse(i_r_idx,s,Other,Nu,Nu);
    
    
    
%%  other items for vertical of v^*
    
    

    i_l = i- v_star_vertical(:,1);%the x value of the interpolation point on the left
    j_l = j- v_star_vertical(:,2);%the y value of the interpolation point on the left


    i_r = i+ v_star_vertical(:,1);%the x value of the interpolation point on the left
    j_r = j+ v_star_vertical(:,2);%the y value of the interpolation point on the left
    
   
    
    
     % find the inner point for the left point
    idx = and(and(1<=i_l,i_l<=N-1),and(1<=j_l,j_l<=N-1));
    s = LocaltoGlobalidx(i_l(idx),j_l(idx),N);
    i_l_idx = find(idx);
    grad_Deltau = Gradu_Deltaeu_v(:,1);
    Other =  grad_Deltau(idx).*Delta_eu(idx);
    Grad_Fu = Grad_Fu + sparse(i_l_idx,s,Other,Nu,Nu);
    
    
    % find the inner point for the right point
    idx = and(and(1<=i_r,i_r<=N-1),and(1<=j_r,j_r<=N-1));
    s = LocaltoGlobalidx(i_r(idx),j_r(idx),N);
    i_r_idx = find(idx);
    grad_Deltau = Gradu_Deltaeu_v(:,2);
    Other =  grad_Deltau(idx).*Delta_eu(idx);
    Grad_Fu = Grad_Fu + sparse(i_r_idx,s,Other,Nu,Nu);
    
    
    
end
    
