function S = initial(i,j,h)
%% ��u(x,y) = x^2+y^2 Ϊ��ֵ
S = (i*h).^2+(j*h).^2;
end