function Delta_eu = Delta_ess(u,e,h)
%%Find the Delta of u at (ih,jh) in the direction of e, and the grid size is h
global g_D;
N = 1/h;


u_l = zeros(size(u));
u_r = zeros(size(u));

rho_l = ones(size(u));
rho_r = ones(size(u));

[i,j] = GlobaltoLocalidx((1:length(u))',N);

%%


i_l = i-rho_l*e(1);%the x value of the interpolation point on the left
j_l = j-rho_l*e(2);%the y value of the interpolation point on the left




i_r = i+rho_r*e(1);%the x value of the interpolation point on the left
j_r = j+rho_r*e(2);%the y value of the interpolation point on the left



% find the inner point
idx = and(and(1<=i_l,i_l<=N-1),and(1<=j_l,j_l<=N-1));
s = LocaltoGlobalidx(i_l(idx),j_l(idx),N);
u_l(idx) = u(s);



% find the inner point
idx = and(and(1<=i_r,i_r<=N-1),and(1<=j_r,j_r<=N-1));
s = LocaltoGlobalidx(i_r(idx),j_r(idx),N);
u_r(idx) = u(s);


% find the boundary point
if and(e(1)==0,e(2)>0)
    idx = j_l<1;
    rho_l(idx) = (j(idx)-0)/e(2);
    x = (i(idx) - rho_l(idx)*e(1))*h;
    y = (j(idx) - rho_l(idx)*e(2))*h;
    u_l(idx) = g_D(x,y);
    
    idx = j_r>N-1;
    rho_r(idx) = (N-j(idx))/e(2);
    x = (i(idx)+rho_r(idx)*e(1))*h;
    y = (j(idx)+rho_r(idx)*e(2))*h;
    u_r(idx) = g_D(x,y);
    
elseif and(e(1)==0,e(2)<0)
    idx = j_l>N-1;
    rho_l(idx) = (j(idx)-N)/e(2);
    x = (i(idx) - rho_l(idx)*e(1))*h;
    y = (j(idx) - rho_l(idx)*e(2))*h;
    u_l(idx) = g_D(x,y); 
    
    idx = j_r<1;
    rho_r(idx) = (0-j(idx))/e(2);
    x = (i(idx)+rho_r(idx)*e(1))*h;
    y = (j(idx)+rho_r(idx)*e(2))*h;
    u_r(idx) = g_D(x,y);
    
    
elseif and(e(1)>0,e(2)>0)
    idx = or(i_l<1,j_l<1);
    x_rho = (i(idx)-0)'/e(1);
    y_rho = (j(idx)-0)'/e(2);
    rho_l(idx) = min([x_rho;y_rho])';
    x = (i(idx) - rho_l(idx)*e(1))*h;
    y = (j(idx) - rho_l(idx)*e(2))*h;
    u_l(idx) = g_D(x,y); 
    
    idx = or(i_r>N-1,j_r>N-1);
    x_rho = (N-i(idx))'/e(1);
    y_rho = (N-j(idx))'/e(2);
    rho_r(idx) = min([x_rho;y_rho])';
    x = (i(idx)+rho_r(idx)*e(1))*h;
    y = (j(idx)+rho_r(idx)*e(2))*h;
    u_r(idx) = g_D(x,y);
    
    
elseif and(e(1)>0,e(2)==0)
    idx = i_l<1;
    rho_l(idx) = (i(idx)-0)/e(1);
    x = (i(idx) - rho_l(idx)*e(1))*h;
    y = (j(idx) - rho_l(idx)*e(2))*h;
    u_l(idx) = g_D(x,y);
    
    
    idx = i_r>N-1;
    rho_r(idx) = (N-i(idx))/e(1);
    x = (i(idx)+rho_r(idx)*e(1))*h;
    y = (j(idx)+rho_r(idx)*e(2))*h;
    u_r(idx) = g_D(x,y);
    
    
elseif and(e(1)>0,e(2)<0)
    idx = or(i_l<1,j_l>N-1);
    x_rho = (i(idx)-0)'/e(1);
    y_rho = (j(idx)-N)'/e(2);
    rho_l(idx) = min([x_rho;y_rho])';
    x = (i(idx) - rho_l(idx)*e(1))*h;
    y = (j(idx) - rho_l(idx)*e(2))*h;
    u_l(idx) = g_D(x,y); 
    
    idx = or(i_r>N-1,j_r<1);
    x_rho = (N-i(idx))'/e(1);
    y_rho = (0-j(idx))'/e(2);
    rho_r(idx) = min([x_rho;y_rho])';
    x = (i(idx)+rho_r(idx)*e(1))*h;
    y = (j(idx)+rho_r(idx)*e(2))*h;
    u_r(idx) = g_D(x,y);
    
    
    
elseif and(e(1)<0,e(2)>0)
    idx = or(i_l>N-1,j_l<1);
    x_rho = (i(idx)-N)'/e(1);
    y_rho = (j(idx)-0)'/e(2);
    rho_l(idx) = min([x_rho;y_rho])';
    x = (i(idx) - rho_l(idx)*e(1))*h;
    y = (j(idx) - rho_l(idx)*e(2))*h;
    u_l(idx) = g_D(x,y); 
    
    idx = or(i_r<1,j_r>N-1);
    x_rho = (0-i(idx))'/e(1);
    y_rho = (N-j(idx))'/e(2);
    rho_r(idx) = min([x_rho;y_rho])';
    x = (i(idx)+rho_r(idx)*e(1))*h;
    y = (j(idx)+rho_r(idx)*e(2))*h;
    u_r(idx) = g_D(x,y);
    
    
elseif and(e(1)<0,e(2)==0)
    idx = i_l>N-1;
    rho_l(idx) = (i(idx)-N)/e(1);
    x = (i(idx) - rho_l(idx)*e(1))*h;
    y = (j(idx) - rho_l(idx)*e(2))*h;
    u_l(idx) = g_D(x,y);
    
    
    idx = i_r<1;
    rho_r(idx) = (0-i(idx))/e(1);
    x = (i(idx)+rho_r(idx)*e(1))*h;
    y = (j(idx)+rho_r(idx)*e(2))*h;
    u_r(idx) = g_D(x,y);
    
elseif and(e(1)<0,e(2)<0)
    idx = or(i_l>N-1,j_l>N-1);
    x_rho = (i(idx)-N)'/e(1);
    y_rho = (j(idx)-N)'/e(2);
    rho_l(idx) = min([x_rho;y_rho])';
    x = (i(idx) - rho_l(idx)*e(1))*h;
    y = (j(idx) - rho_l(idx)*e(2))*h;
    u_l(idx) = g_D(x,y); 
    
    idx = or(i_r<1,j_r<1);
    x_rho = (0-i(idx))'/e(1);
    y_rho = (0-j(idx))'/e(2);
    rho_r(idx) = min([x_rho;y_rho])';
    x = (i(idx)+rho_r(idx)*e(1))*h;
    y = (j(idx)+rho_r(idx)*e(2))*h;
    u_r(idx) = g_D(x,y);
    
    
end






Delta_eu = ((u_r-u)./rho_r-(u-u_l)./rho_l).*(2./((rho_l+rho_r).*(e(1)^2+e(2)^2).*h^2));

end







